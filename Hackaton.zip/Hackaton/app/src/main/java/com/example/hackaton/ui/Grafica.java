package com.example.hackaton.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.example.hackaton.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Grafica extends Fragment {

    private AnyChartView chartView;
    private Cartesian cartesianChart;
    private DatabaseReference databaseReference;
    private List<DataEntry> ch4Data;
    private List<DataEntry> co2Data;

    public static Grafica newInstance() {
        return new Grafica();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_grafica, container, false);

        // Initialize data lists
        ch4Data = new ArrayList<>();
        co2Data = new ArrayList<>();

        chartView = view.findViewById(R.id.chartView);
        cartesianChart = AnyChart.line();

        setupChart();
        chartView.setChart(cartesianChart);

        // Firebase configuration
        databaseReference = FirebaseDatabase.getInstance().getReference("sensor_data");

        listenForData();

        return view;
    }

    private void setupChart() {
        cartesianChart.animation(true);
        cartesianChart.title("Gases");

        cartesianChart.yAxis(0).title("Concentracion(PPM)");
        cartesianChart.xAxis(0).title("Tiempo");

        cartesianChart.xScroller(true);
        cartesianChart.xZoom().setTo(0.0, 1.0);

        // Legend configuration
        cartesianChart.legend().enabled(true);
        cartesianChart.legend().fontSize(13);
        cartesianChart.legend().padding(0, 0, 20, 0);
        cartesianChart.legend().itemsLayout(LegendLayout.HORIZONTAL);
        cartesianChart.legend().align(Align.CENTER);
    }

    private void updateChart() {
        Log.d("Grafica", "Updating chart with data");

        cartesianChart.removeAllSeries();

        if (!ch4Data.isEmpty()) {
            Line ch4Line = cartesianChart.line(ch4Data);
            ch4Line.name("CH4").color("#FFA500"); // Orange
        }

        if (!co2Data.isEmpty()) {
            Line co2Line = cartesianChart.line(co2Data);
            co2Line.name("CO2").color("#0000FF"); // Blue
        }

        chartView.setChart(cartesianChart);
    }

    private void listenForData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("Grafica", "Data changed");

                ch4Data.clear();
                co2Data.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Integer ch4Value = snapshot.child("/CH4").getValue(Integer.class);
                    Integer co2Value = snapshot.child("/CO2").getValue(Integer.class);
                    String timestamp = snapshot.getKey();

                    if (ch4Value != null && co2Value != null) {
                        Log.d("Grafica", "timestamp: " + timestamp + ", CH4: " + ch4Value + ", CO2: " + co2Value);
                        ch4Data.add(new ValueDataEntry(timestamp, ch4Value));
                        co2Data.add(new ValueDataEntry(timestamp, co2Value));
                    } else {
                        Log.d("Grafica", "Missing data for timestamp: " + timestamp);
                    }
                }

                Log.d("Grafica", "CH4 Data size: " + ch4Data.size());
                Log.d("Grafica", "CO2 Data size: " + co2Data.size());

                updateChart();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Grafica", "Error: " + databaseError.getMessage());
            }
        });
    }
}
