package com.example.hackaton.ui;

import androidx.lifecycle.ViewModel;

public class GraficaViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}