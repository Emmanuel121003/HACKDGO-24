package com.example.hackaton.ui.gallery;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.example.hackaton.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class GalleryFragment extends AppCompatActivity {

    private AnyChartView chartView;
    private Cartesian cartesianChart;
    private DatabaseReference databaseReference;
    private List<DataEntry> ch4Data;
    private List<DataEntry> co2Data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_gallery);

        // Inicializar las listas
        ch4Data = new ArrayList<>();
        co2Data = new ArrayList<>();

        chartView = findViewById(R.id.chartView);
        cartesianChart = AnyChart.line();

        setupChart();

        // Configuración de Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("sensor_data");

        listenForData();
    }

    private void setupChart() {
        cartesianChart.animation(true);
        cartesianChart.title("Datos Sensor");

        cartesianChart.yAxis(0).title("PPM");
        cartesianChart.xAxis(0).title("Tiempo");

        cartesianChart.xScroller(true);
        cartesianChart.xZoom().setTo(0.0, 1.0);

        // Configuración de la leyenda
        cartesianChart.legend().enabled(true);
        cartesianChart.legend().fontSize(13);
        cartesianChart.legend().padding(0, 0, 20, 0);
        cartesianChart.legend().itemsLayout(LegendLayout.HORIZONTAL);
        cartesianChart.legend().align(Align.CENTER);

        chartView.setChart(cartesianChart);
    }

    private void updateChart() {
        Log.d("GalleryFragment", "Updating chart with data");

        if (cartesianChart == null) {
            Log.e("GalleryFragment", "Cartesian chart is null");
            return;
        }

        cartesianChart.removeAllSeries();

        if (!ch4Data.isEmpty()) {
            Line ch4Line = cartesianChart.line(ch4Data);
            ch4Line.name("CH4").color("#FFA500"); // Orange
        }

        if (!co2Data.isEmpty()) {
            Line co2Line = cartesianChart.line(co2Data);
            co2Line.name("CO2").color("#0000FF"); // Blue
        }

        chartView.setChart(cartesianChart);
    }

    private void listenForData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Log.d("GalleryFragment", "Data changed");

                if (ch4Data == null) {
                    ch4Data = new ArrayList<>();
                }
                if (co2Data == null) {
                    co2Data = new ArrayList<>();
                }

                ch4Data.clear();
                co2Data.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Integer ch4Value = snapshot.child("CH4").getValue(Integer.class);
                    Integer co2Value = snapshot.child("CO2").getValue(Integer.class);
                    String timestamp = snapshot.getKey();

                    if (ch4Value != null && co2Value != null) {
                        Log.d("GalleryFragment", "Timestamp: " + timestamp + ", CH4: " + ch4Value + ", CO2: " + co2Value);
                        ch4Data.add(new ValueDataEntry(timestamp, ch4Value));
                        co2Data.add(new ValueDataEntry(timestamp, co2Value));
                    } else {
                        Log.d("GalleryFragment", "Missing data for timestamp: " + timestamp);
                    }
                }

                // Verifica si los datos están vacíos
                Log.d("GalleryFragment", "CH4 Data size: " + ch4Data.size());
                Log.d("GalleryFragment", "CO2 Data size: " + co2Data.size());

                updateChart();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("GalleryFragment", "Error: " + databaseError.getMessage());
            }
        });
    }
}
