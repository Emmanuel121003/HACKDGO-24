package com.example.hackaton.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.enums.Align;
import com.anychart.enums.LegendLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class GalleryViewModel extends ViewModel {

    private final MutableLiveData<List<DataEntry>> ch4Data;
    private final MutableLiveData<List<DataEntry>> co2Data;

    private final DatabaseReference databaseReference;

    public GalleryViewModel() {
        ch4Data = new MutableLiveData<>(new ArrayList<>());
        co2Data = new MutableLiveData<>(new ArrayList<>());
        databaseReference = FirebaseDatabase.getInstance().getReference("sensor_data");

        // Escuchar datos de Firebase
        listenForData();
    }

    public LiveData<List<DataEntry>> getCh4Data() {
        return ch4Data;
    }

    public LiveData<List<DataEntry>> getCo2Data() {
        return co2Data;
    }

    private void listenForData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<DataEntry> newCh4Data = new ArrayList<>();
                List<DataEntry> newCo2Data = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Integer ch4Value = snapshot.child("CH4").getValue(Integer.class);
                    Integer co2Value = snapshot.child("CO2").getValue(Integer.class);
                    String timestamp = snapshot.getKey(); // Asumiendo que el timestamp es la clave

                    if (ch4Value != null && co2Value != null) {
                        newCh4Data.add(new ValueDataEntry(timestamp, ch4Value));
                        newCo2Data.add(new ValueDataEntry(timestamp, co2Value));
                    }
                }

                ch4Data.setValue(newCh4Data);
                co2Data.setValue(newCo2Data);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Manejo de errores
            }
        });
    }
}