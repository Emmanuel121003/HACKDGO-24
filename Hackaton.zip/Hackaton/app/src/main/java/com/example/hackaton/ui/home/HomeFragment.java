package com.example.hackaton.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.hackaton.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    private TextView ch4Value, co2Value, fc28Value, humidityValue, temperatureValue;
    private DatabaseReference databaseReference;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        // Referenciar los TextView del layout
        ch4Value = root.findViewById(R.id.ch4_value);
        co2Value = root.findViewById(R.id.co2_value);
        fc28Value = root.findViewById(R.id.fc28_value);
        humidityValue = root.findViewById(R.id.humidity_value);
        temperatureValue = root.findViewById(R.id.temperature_value);

        // Inicializar la referencia a Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("sensor_data");

        // Añadir un listener para obtener los datos en tiempo real de Firebase
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Obtener los últimos valores almacenados de los sensores
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        // Valores de los sensores
                        float CH4 = snapshot.child("CH4").getValue(Float.class);
                        float CO2 = snapshot.child("CO2").getValue(Float.class);
                        float FC28 = snapshot.child("FC28").getValue(Float.class);
                        float Humidity = snapshot.child("Humidity").getValue(Float.class);
                        float Temperature = snapshot.child("Temperature").getValue(Float.class);

                        // Actualizar los TextView con los valores obtenidos
                        ch4Value.setText(CH4 + " ppm");
                        co2Value.setText(CO2 + " ppm");
                        fc28Value.setText(FC28 + " %");
                        humidityValue.setText(Humidity + " %");
                        temperatureValue.setText(Temperature + " °C");
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Manejar el error de lectura
            }
        });

        return root;
    }
}
