package com.example.hackaton.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeViewModel extends ViewModel {
    private final MutableLiveData<SensorData> sensorData = new MutableLiveData<>();

    public LiveData<SensorData> getSensorData() {
        return sensorData;
    }

    public void fetchDataFromFirebase() {
        DatabaseReference databaseRef = FirebaseDatabase.getInstance().getReference("sensorData");
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                SensorData data = snapshot.getValue(SensorData.class);
                sensorData.setValue(data);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Manejo de errores
            }
        });
    }
}
