package com.example.hackaton.ui.home;

public class SensorData {
    private float CH4;
    private float CO2;
    private float FC28;
    private float Humidity;
    private float Temperature;

    // Constructor vacío necesario para Firebase
    public SensorData() {
        this.CH4 = 0.0f;
        this.CO2 = 0.0f;
        this.FC28 = 0.0f;
        this.Humidity = 0.0f;
        this.Temperature = 0.0f;
    }

    // Constructor opcional con parámetros para inicializar directamente
    public SensorData(float CH4, float CO2, float FC28, float Humidity, float Temperature) {
        this.CH4 = CH4;
        this.CO2 = CO2;
        this.FC28 = FC28;
        this.Humidity = Humidity;
        this.Temperature = Temperature;
    }

    // Getters y setters
    public float getCH4() {
        return CH4;
    }

    public void setCH4(float CH4) {
        this.CH4 = CH4;
    }

    public float getCO2() {
        return CO2;
    }

    public void setCO2(float CO2) {
        this.CO2 = CO2;
    }

    public float getFC28() {
        return FC28;
    }

    public void setFC28(float FC28) {
        this.FC28 = FC28;
    }

    public float getHumidity() {
        return Humidity;
    }

    public void setHumidity(float Humidity) {
        this.Humidity = Humidity;
    }

    public float getTemperature() {
        return Temperature;
    }

    public void setTemperature(float Temperature) {
        this.Temperature = Temperature;
    }

    // Método adicional para facilitar la visualización de datos
    @Override
    public String toString() {
        return "SensorData{" +
                "CH4=" + CH4 +
                ", CO2=" + CO2 +
                ", FC28=" + FC28 +
                ", Humidity=" + Humidity +
                ", Temperature=" + Temperature +
                '}';
    }
}
