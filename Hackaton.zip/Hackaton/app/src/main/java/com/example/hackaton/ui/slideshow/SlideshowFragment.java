package com.example.hackaton.ui.slideshow;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.hackaton.R;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class SlideshowFragment extends Fragment {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        // Inflar el layout del fragmento
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        // ImageView para mostrar la imagen desde Firebase Storage
        ImageView imageView = root.findViewById(R.id.imageView);

        // Referencia a Firebase Storage
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

        // Ruta de la imagen en Firebase Storage
        StorageReference imageRef = storageRef.child("agrobot.jpg");

        // Obtener la URL de descarga de la imagen
        imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
            // Usar Picasso para cargar la imagen en el ImageView
            Picasso.get().load(uri).into(imageView);
        }).addOnFailureListener(e -> {
            // Manejar el error
            Toast.makeText(getContext(), "Error al cargar la imagen", Toast.LENGTH_SHORT).show();
        });

        return root;
    }
}
