package com.example.hackaton.ui.slideshow;

import androidx.lifecycle.ViewModel;

public class SlideshowViewModel extends ViewModel {
    // Aquí puedes implementar lógica adicional si es necesario
}
